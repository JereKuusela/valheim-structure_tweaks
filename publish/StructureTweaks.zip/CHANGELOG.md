- v1.16
  - Adds support for timed destroy.

- v1.15
  - Adds support for changing the environment in dungeons.
  - Adds support for changing the dungeon entrance texts.
  - Fixes all custom objects not working.

- v1.14
  - Adds support for vegvisirs in dungeons.
  
- v1.13
  - Fixes non-instant transition not working for weather effects.

- v1.12
  - Fixes error when trying to chop tree logs.

- v1.11
  - Fixes experience gain from infinite health object.
  - Fixes error when using mods that add multiple chests per object.

- v1.10
  - Fixes null error with some mods.

- v1.9
  - Adds support for adding a custom sized water surface.
  - Fixes the black screen.
